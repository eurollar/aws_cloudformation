const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const USERS_TABLE = process.env.USERS_TABLE;

const CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Content-Type": "application/json"
};

exports.handler = async (event) => {
    console.log("Incoming event:", event);

    try {
        if (!event.body) {
            console.warn("Request body is empty.");
            return {
                statusCode: 400,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Request body cannot be empty." }),
            };
        }

        const { username, password, email } = JSON.parse(event.body);

        if (!username) {
            console.warn("Validation error: Username is required.");
            return {
                statusCode: 400,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Username is required." }),
            };
        }

        if (!password) {
            console.warn("Validation error: Password is required.");
            return {
                statusCode: 400,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Password is required." }),
            };
        }

        if (!email) {
            console.warn("Validation error: Email is required.");
            return {
                statusCode: 400,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Email is required." }),
            };
        }

        console.log(`Checking if user "${username}" already exists in table "${USERS_TABLE}"`);
        const existingUser = await dynamoDb
            .get({ TableName: USERS_TABLE, Key: { username } })
            .promise();

        if (existingUser.Item) {
            console.warn(`User "${username}" already exists.`);
            return {
                statusCode: 409, // Use 409 Conflict for existing resource
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "User with this username already exists." }),
            };
        }

        console.log(`Hashing password for user "${username}"`);
        const passwordHash = await bcrypt.hash(password, 10);
        console.log(`Password hashed successfully.`);

        console.log(`Storing user "${username}" in DynamoDB table "${USERS_TABLE}"`);
        const putParams = {
            TableName: USERS_TABLE,
            Item: {
                username: username,
                passwordHash: passwordHash,
                email: email,
                registrationDate: new Date().toISOString(),
            },
        };

        await dynamoDb.put(putParams).promise();
        console.log(`User "${username}" stored successfully.`);

        const successResponse = {
            statusCode: 201, // Use 201 Created for successful registration
            headers: CORS_HEADERS,
            body: JSON.stringify({ message: "User registered successfully.", username: username, email: email }),
        };
        console.log("Registration successful:", successResponse);
        return successResponse;

    } catch (error) {
        console.error("Registration error:", error);
        let statusCode = 500;
        let message = "Internal server error";

        if (error instanceof SyntaxError && error.message.includes("JSON")) {
            statusCode = 400;
            message = "Invalid JSON in request body.";
        } else if (error.code === 'ValidationException') {
            statusCode = 400;
            message = "Validation error with DynamoDB.";
        } else {
            message += ` - ${error.message}`;
        }

        const errorResponse = {
            statusCode: statusCode,
            headers: CORS_HEADERS,
            body: JSON.stringify({ message: message, error: error.message }),
        };
        console.error("Error response:", errorResponse);
        return errorResponse;
    }
};
