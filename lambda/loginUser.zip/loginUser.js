const AWS = require('aws-sdk');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const USERS_TABLE = process.env.USERS_TABLE;
const JWT_SECRET = process.env.JWT_SECRET;

const CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Content-Type": "application/json"
};

exports.handler = async (event) => {
    console.log("Incoming event:", event);

    try {
        if (!event.body) {
            console.warn("Request body is empty.");
            return {
                statusCode: 400,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Request body cannot be empty." }),
            };
        }

        const { username, password } = JSON.parse(event.body);

        if (!username) {
            console.warn("Validation error: Username is required.");
            return {
                statusCode: 400,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Username is required." }),
            };
        }

        if (!password) {
            console.warn("Validation error: Password is required.");
            return {
                statusCode: 400,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Password is required." }),
            };
        }

        console.log(`Retrieving user "${username}" from table "${USERS_TABLE}"`);
        const user = await dynamoDb
            .get({ TableName: USERS_TABLE, Key: { username } })
            .promise();

        if (!user.Item) {
            console.warn(`User "${username}" not found.`);
            return {
                statusCode: 401,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Invalid credentials." }),
            };
        }

        console.log(`Comparing password for user "${username}"`);
        const isValidPassword = await bcrypt.compare(password, user.Item.passwordHash);

        if (!isValidPassword) {
            console.warn(`Password for user "${username}" does not match.`);
            return {
                statusCode: 401,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Invalid credentials." }),
            };
        }

        console.log(`Generating JWT token for user "${username}"`);
        if (!JWT_SECRET) {
            console.error("JWT_SECRET environment variable is not set!");
            return {
                statusCode: 500,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Internal server error: JWT secret not configured." }),
            };
        }
        const token = jwt.sign({ username: user.Item.username }, JWT_SECRET, { expiresIn: '1h' });
        console.log(`JWT token generated successfully.`);

        const successResponse = {
            statusCode: 200,
            headers: CORS_HEADERS,
            body: JSON.stringify({ token }),
        };
        console.log("Login successful:", successResponse);
        return successResponse;

    } catch (error) {
        console.error("Login error:", error);
        let statusCode = 500;
        let message = "Internal server error";

        if (error instanceof SyntaxError && error.message.includes("JSON")) {
            statusCode = 400;
            message = "Invalid JSON in request body.";
        } else if (error.code === 'ValidationException') {
            statusCode = 400;
            message = "Validation error with DynamoDB.";
        } else {
            message += ` - ${error.message}`;
        }

        const errorResponse = {
            statusCode: statusCode,
            headers: CORS_HEADERS,
            body: JSON.stringify({ message: message, error: error.message }),
        };
        console.error("Error response:", errorResponse);
        return errorResponse;
    }
};
