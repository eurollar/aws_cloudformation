const AWS = require('aws-sdk');
const jwt = require('jsonwebtoken');

const dynamoDb = new AWS.DynamoDB.DocumentClient();
const USERS_TABLE = process.env.USERS_TABLE;
const JWT_SECRET = process.env.JWT_SECRET;

const CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,Authorization",
    "Content-Type": "application/json"
};

exports.handler = async (event) => {
    console.log("Incoming event:", event);

    try {
        const token = event.headers ? event.headers.Authorization : null;

        if (!token) {
            console.warn("Unauthorized: No token provided in headers.");
            return {
                statusCode: 401,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Unauthorized: No token provided." }),
            };
        }

        console.log("Verifying JWT token:", token.substring(0, 20) + "..."); // Log a part of the token

        let decoded;
        try {
            if (!JWT_SECRET) {
                console.error("JWT_SECRET environment variable is not set!");
                return {
                    statusCode: 500,
                    headers: CORS_HEADERS,
                    body: JSON.stringify({ message: "Internal server error: JWT secret not configured." }),
                };
            }
            decoded = jwt.verify(token, JWT_SECRET);
            console.log("JWT token verified successfully. Decoded payload:", decoded);
        } catch (err) {
            console.warn("Unauthorized: Invalid token.", err);
            return {
                statusCode: 401,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "Unauthorized: Invalid token." }),
            };
        }

        console.log(`Retrieving user info for "${decoded.username}" from table "${USERS_TABLE}"`);
        const user = await dynamoDb
            .get({ TableName: USERS_TABLE, Key: { username: decoded.username } })
            .promise();

        if (!user.Item) {
            console.warn(`User "${decoded.username}" not found in table "${USERS_TABLE}".`);
            return {
                statusCode: 404,
                headers: CORS_HEADERS,
                body: JSON.stringify({ message: "User not found." }),
            };
        }

        const { username, email } = user.Item;
        const successResponse = {
            statusCode: 200,
            headers: CORS_HEADERS,
            body: JSON.stringify({ username, email }),
        };
        console.log("Successfully retrieved user info:", successResponse);
        return successResponse;

    } catch (error) {
        console.error("Get user info error:", error);
        let statusCode = 500;
        let message = "Internal server error";

        if (error instanceof SyntaxError && error.message.includes("JSON")) {
            statusCode = 400;
            message = "Invalid JSON in request body (this is unlikely for getUserInfo).";
        } else if (error.code === 'ValidationException') {
            statusCode = 400;
            message = "Validation error with DynamoDB.";
        } else {
            message += ` - ${error.message}`;
        }

        const errorResponse = {
            statusCode: statusCode,
            headers: CORS_HEADERS,
            body: JSON.stringify({ message: message, error: error.message }),
        };
        console.error("Error response:", errorResponse);
        return errorResponse;
    }
};
